package com.example.user.taiwanese;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaRecorder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class M1 extends AppCompatActivity {

    TextView textResult;
    ImageButton record;
    private boolean busy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m1);
        initUI();
        permissionCheck();
        textResult.setText("辨識結果");
        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!busy && checkNetWork()){
                    busy = true;
                    textResult.setText("正在辨識...");
                    startTaiwaneseRecognition();
                }
            }
        });
    }
    private void initUI(){
        busy = false;
        textResult = (TextView)findViewById(R.id.tv1);
        record = (ImageButton)findViewById(R.id.imageButton);
    }
    private void permissionCheck(){
        int permission1 = ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permission2 = ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
        if(permission1 != PackageManager.PERMISSION_GRANTED || permission2 != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(M1.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.RECORD_AUDIO},1);
        }
    }
    private boolean checkNetWork(){
        ConnectivityManager mCM = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        assert mCM != null;
        NetworkInfo mNI = mCM.getActiveNetworkInfo();
        if(mNI != null && mNI.isConnected()){
            return true;
        }
        else{
            Toast.makeText(this,"無網路連線",Toast.LENGTH_SHORT).show();
            return true;
        }
    }
    //START　RECORD
    private File recordFile;
    private MediaRecorder mediaRecorder= new MediaRecorder();
    private void startTaiwaneseRecognition(){
        try{
            recordFile = File.createTempFile("record_temp",".m4a",getCacheDir());
            mediaRecorder.setOutputFile(recordFile.getAbsolutePath());
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setAudioEncodingBitRate(326000);
            mediaRecorder.setAudioSamplingRate(44100);
            mediaRecorder.setAudioChannels(1);
            mediaRecorder.prepare();
            mediaRecorder.start();

        }catch (IOException e){
            pushResult(e.getMessage(),false);
            e.printStackTrace();
        }
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.layout2);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                endTaiwaneseRecognition();
            }
        });
        ImageButton btnComplete = (ImageButton) dialog.findViewById(R.id.imageButton2);
        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        TextView textView = (TextView) dialog.findViewById(R.id.tv2);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }

        });
        dialog.show();

    }
    private void endTaiwaneseRecognition(){
        mediaRecorder.stop();
        new TaiwaneseSender().execute(recordFile.getAbsolutePath());
    }
    private void pushResult(String msg,boolean sucess){
        if(sucess){
            textResult.setText(msg);

        }
        textResult.setText(msg);
        busy = false;
    }
    //******************************************************************
    @SuppressLint("StaticFieldLeak")
    public class TaiwaneseSender extends AsyncTask <String, Void, String> {
        // 伺服器核發之安全性token
        private static final String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzUxMiJ9.eyJpZCI6MjIsInVzZXJfaWQiOiIxMiIsInNlcnZpY2VfaWQiOiIzIiwic2NvcGVzIjoiMCIsInN1YiI6IiIsImlhdCI6MTUzNjczNTY0MywibmJmIjoxNTM2NzM1NjQzLCJleHAiOjE1NDQ1MTE2NDMsImlzcyI6IkpXVCIsImF1ZCI6IndtbWtzLmNzaWUuZWR1LnR3IiwidmVyIjowLjF9.DURt5xZHjb_k9uFw-vhsuTddrsXnDXCYg8yOZzhdi1Xy_-29C3JYOugPlCSrPPUvjDTY4HHu-miXUV2HTKDra5wZ9XfXx0Ee8bKTMQwfSJnA1ykrTWeGI8XbnYQqjX0C-ze1sauWq2Na-GCZnliXYoxlsz6nkNV8YWzsyG7c2po";

        // 所要使用之模型名稱
        private static final String model = "main";

        // 伺服器資訊
        private static final String host = "140.116.245.149";
        private static final int port = 2802;

        @Override
        protected String doInBackground(String... param) {
            String padding = new String(new char[8 - model.length()])
                    .replace("\0", "\u0000");
            String label = "A";
            String header = token + "@@@" + model + padding + label;

            try {
                byte[] b_header = header.getBytes();
                byte[] b_sample = readAsByteArray(param[0]);

                int len = b_header.length + b_sample.length;
                byte[] b_len = new byte[4];
                b_len[0] = (byte) ((len & 0xff000000) >>> 24);
                b_len[1] = (byte) ((len & 0x00ff0000) >>> 16);
                b_len[2] = (byte) ((len & 0x0000ff00) >>> 8);
                b_len[3] = (byte) ((len & 0x000000ff));

                ByteArrayOutputStream arrayOutput = new ByteArrayOutputStream();
                arrayOutput.write(b_len);
                arrayOutput.write(b_header);
                arrayOutput.write(b_sample);

                Socket socket = new Socket();
                InetSocketAddress socketAddress = new InetSocketAddress(host, port);
                socket.connect(socketAddress, 1000);

                // 將訊息傳至server
                BufferedOutputStream sout = new BufferedOutputStream(socket.getOutputStream());
                sout.write(arrayOutput.toByteArray());
                sout.flush();

                // 從server接收訊息
                arrayOutput = new ByteArrayOutputStream();
                byte[] buf = new byte[1024];
                BufferedInputStream sin = new BufferedInputStream(socket.getInputStream());
                while (sin.read(buf) > 0) {
                    arrayOutput.write(buf);
                }

                sout.close();
                sin.close();
                socket.close();

                return new String(arrayOutput.toByteArray(), Charset.forName("UTF-8"));
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            Matcher match = Pattern.compile("result:(.*)\n?").matcher(s);
            if (match.find()) {
                pushResult(match.group(1).replace(" ", ""), true);
            } else {
                pushResult("辨識失敗", false);
            }
        }

        private byte[] readAsByteArray(String path) throws IOException {
            FileInputStream fis = new FileInputStream(path);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            for (int readNum; (readNum = fis.read(b)) != -1; ) {
                bos.write(b, 0, readNum);
            }

            return bos.toByteArray();
        }
    }

}
